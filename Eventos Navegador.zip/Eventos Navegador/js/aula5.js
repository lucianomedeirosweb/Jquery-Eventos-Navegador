
$(function(){
	
					
<!-- uma forma de fazer -->
/* $('img').error(function(){
	
	$('img').attr("src","img/cara.jpg");
	*/
	
	
	
	
	<!-- uma forma de fazer -->
	/* $('img').error(function(){
     
	 var imagem = $(this).attr("src");
	 alert('Imagem' +imagem+ 'Indisponivel'); */
	 
	 
	 
	/* <!-- $('img').width($(window).width());	 --> */

<!-- Redimensionar automaticamente a imagem -->

  /* $(window).resize(function(){
	
	<!-- $('img').width($(window).width());
	
})	
*/
<!-- Sumir a imagem quando o Scroll se movimentar --> 
/* $(window).scroll(function(){
	
	
	$('img').fadeOut('1000');
	*/
	$('body').css("height","5000px");
	$(window).scroll(function(){
	
	
	var topo = $(window).scrollTop();
	 alert(topo);
	
	
	
	
})



	
	
});
			
